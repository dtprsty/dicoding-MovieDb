package com.example.prasetyo.moviedb.main;

import com.example.prasetyo.moviedb.model.Movie;

import java.util.ArrayList;

public interface MovieView {
    public void showLoading();
    public void hideLoading();
    public void showSnackbar(String message);
    public void getMovie(ArrayList<Movie> data);
}
