package com.example.prasetyo.moviedb.main;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.prasetyo.moviedb.R;
import com.example.prasetyo.moviedb.api.ApiEndPoint;
import com.example.prasetyo.moviedb.detail.DetailMovieActivity;
import com.example.prasetyo.moviedb.model.Movie;
import com.example.prasetyo.moviedb.util.RecyclerItemClickListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MovieView {

    private MovieAdapter adapter;
    private MoviePresenter presenter;
    private ArrayList<Movie> itemList = new ArrayList<Movie>();

    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private ProgressDialog pDialog;

    private EditText txTitle;
    private Button btnCari;
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        btnCari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                presenter.getMovie(txTitle.getText().toString().replace(" ", "%20"));
                initRecyclerView();
            }
        });


        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        // TODO Handle item click
                        Movie m = itemList.get(position);

                        Intent i = new Intent(MainActivity.this, DetailMovieActivity.class);
                        i.putExtra(DetailMovieActivity.EXTRA_TITLE, m.getTitle());
                        i.putExtra(DetailMovieActivity.EXTRA_DATE, m.getDate());
                        i.putExtra(DetailMovieActivity.EXTRA_OVERVIEW, m.getOverview());
                        i.putExtra(DetailMovieActivity.EXTRA_POSTER, m.getPoster());
                        startActivity(i);
                    }
                })
        );

    }

    private void init() {
        ApiEndPoint apiEndPoint = new ApiEndPoint();
        presenter = new MoviePresenter(this, apiEndPoint);

        btnCari = (Button) findViewById(R.id.btnCari);
        txTitle = (EditText) findViewById(R.id.txTitle);
        root = (LinearLayout) findViewById(R.id.rootView);
        recyclerView = (RecyclerView) findViewById(R.id.listMovie);
        recyclerView.setHasFixedSize(true);
        requestPermission();
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
    }

    private void requestPermission() {
        Dexter.withActivity(this)
                .withPermissions(
                        Manifest.permission.INTERNET,
                        Manifest.permission.ACCESS_NETWORK_STATE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            Toast.makeText(getApplicationContext(), "All permissions are granted!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            showSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Error occurred! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    private void showSettingsDialog() {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Need Permissions");
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton("GOTO SETTINGS", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                openSettings();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();

    }

    // navigating user to app settings
    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    private void initRecyclerView() {
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(MainActivity.this, DividerItemDecoration.VERTICAL));
        // untuk mengisi data dari JSON ke dalam adapter
        itemList.clear();
        adapter = new MovieAdapter(this, itemList);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void showLoading() {
        if (!pDialog.isShowing())
            pDialog.show();

    }

    @Override
    public void hideLoading() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public void showSnackbar(String message) {
        Snackbar snackbar = Snackbar
                .make(root, message, Snackbar.LENGTH_LONG);

        snackbar.show();
    }

    @Override
    public void getMovie(ArrayList<Movie> data) {

        itemList.clear();
        itemList.addAll(data);
        adapter.notifyDataSetChanged();

    }
}
