package com.example.prasetyo.moviedb.main;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.androidnetworking.widget.ANImageView;
import com.example.prasetyo.moviedb.R;
import com.example.prasetyo.moviedb.model.Movie;

import java.util.ArrayList;

public class MovieAdapter extends
        RecyclerView.Adapter<MovieAdapter.ViewHolder> {

    private static final String TAG = MovieAdapter.class.getSimpleName();

    private Context context;
    private ArrayList<Movie> list;

    public MovieAdapter(Context context, ArrayList<Movie> list) {
        this.context = context;
        this.list = list;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txTitle, txOverview, txDate;
        ANImageView moviePoster;


        public ViewHolder(View v) {
            super(v);
            txTitle = (TextView) v.findViewById(R.id.txTitle);
            txOverview = (TextView) v.findViewById(R.id.txOverview);
            txDate = (TextView) v.findViewById(R.id.txReleaseDate);
            moviePoster = (ANImageView) v.findViewById(R.id.movie_poster);
        }
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // membuat view baru
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_movie_row, parent, false);
        // mengeset ukuran view, margin, padding, dan parameter layout lainnya
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.txTitle.setText(list.get(position).getTitle());
        holder.txOverview.setText(list.get(position).getOverview());
        holder.txDate.setText(list.get(position).getDate());
        holder.moviePoster.setImageUrl(list.get(position).getPoster());
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public void notifyData(ArrayList<Movie> myList) {
        this.list = myList;
        notifyDataSetChanged();
    }

}