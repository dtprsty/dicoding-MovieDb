package com.example.prasetyo.moviedb.api;

import com.example.prasetyo.moviedb.BuildConfig;

public class ApiEndPoint {

    public ApiEndPoint(){

    }

    public String url(String title){
        return BuildConfig.BASE_URL + "3/search/movie?api_key="+BuildConfig.TSDB_API_KEY + "&language=en-US&query="+title;
    }
}
