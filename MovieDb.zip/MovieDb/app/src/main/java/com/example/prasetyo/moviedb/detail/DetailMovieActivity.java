package com.example.prasetyo.moviedb.detail;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.androidnetworking.widget.ANImageView;
import com.example.prasetyo.moviedb.R;
import com.example.prasetyo.moviedb.main.MainActivity;

public class DetailMovieActivity extends AppCompatActivity {

    public static String EXTRA_TITLE = "extra_title";
    public static String EXTRA_DATE = "extra_date";
    public static String EXTRA_OVERVIEW = "extra_overview";
    public static String EXTRA_POSTER = "extra_poster";

    private TextView txTitle, txDate, txOverview;
    private ANImageView imgPoster;
    private Button btnBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);

        String title = getIntent().getStringExtra(EXTRA_TITLE);
        String date = getIntent().getStringExtra(EXTRA_DATE);
        String overview = getIntent().getStringExtra(EXTRA_OVERVIEW);
        String poster = getIntent().getStringExtra(EXTRA_POSTER);

        init();
        txTitle.setText(title);
        txDate.setText(date);
        txOverview.setText(overview);
        imgPoster.setImageUrl(poster);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DetailMovieActivity.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });
    }


    private void init(){

        txTitle = (TextView) findViewById(R.id.txTitle);
        txDate = (TextView) findViewById(R.id.txDate);
        txOverview= (TextView) findViewById(R.id.txOverview);
        imgPoster = (ANImageView) findViewById(R.id.imgPoster);
        btnBack = (Button) findViewById(R.id.btnBack);

        setTitle("Movie Detail");

    }
}
